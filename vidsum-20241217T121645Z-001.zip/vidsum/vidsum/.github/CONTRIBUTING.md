# Contributors

> This work is made possible thanks to all of our great and wonderful contributers. To get involved, feel free to fork the repo, make changes and submit a pull request with [this template](https://github.com/OpenGenus/vidsum/blob/master/.github/COMMIT_TEMPLATE.md). 

## Contributors

Thanks goes to these wonderful people who made this possible:

<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
| [<img src="https://avatars3.githubusercontent.com/u/10634210?v=4" width="100px;"/><br /><sub>Aditya Chatterjee</sub>](https://github.com/AdiChat)<br /> | [<img src="https://avatars1.githubusercontent.com/u/1000117?v=4" width="100px;"/><br /><sub>Larry Gray</sub>](https://github.com/lwgray)<br /> | [<img src="https://avatars1.githubusercontent.com/u/11667059?v=4" width="100px;"/><br /><sub>Jay Turner</sub>](https://github.com/JayTurnr)<br /> | [<img src="https://avatars1.githubusercontent.com/u/934782?v=4" width="100px;"/><br /><sub>Trevor</sub>](https://github.com/grimd34th)<br /> | [<img src="https://avatars2.githubusercontent.com/u/17149476?v=4" width="100px;"/><br /><sub>Subbu Dantu</sub>](https://github.com/subkrish)<br /> | [<img src="https://avatars2.githubusercontent.com/u/16636569?v=4" width="100px;"/><br /><sub>Nikhil Nayak</sub>](https://github.com/codebu5ter)<br /> | [<img src="https://avatars2.githubusercontent.com/u/22165670?v=4&s=400" width="100px;"/><br /><sub>C Shri Akhil</sub>](https://github.com/TheGamer007)<br /> | [<img src="https://avatars3.githubusercontent.com/u/5447064?v=4&s=400" width="100px;"/><br /><sub>Vipul</sub>](https://github.com/vipul-sharma20)<br /> | [<img src="https://avatars3.githubusercontent.com/u/22936570?v=4&s=400" width="100px;"/><br /><sub>Bhavesh Anand</sub>](https://github.com/bhaveshAn)<br /> | [<img src="https://avatars2.githubusercontent.com/u/3661681?v=4&s=400" width="100px;"/><br /><sub>James C.</sub>](https://github.com/JamesMCo)<br /> |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
<!-- ALL-CONTRIBUTORS-LIST:END -->

